import "../assets/styles/globals.css";
import Header from "./components/Hearder";
//import Footer from "./components/Footer";

export const metadata = {
    title: "One Ring Rentals",
    keywords: "rental, property, real estate",
    description: "Find the perfect rental property -- A modern web application built with Next.js and Bootstrap",
  };

const MainLayout = ({ children }) => {
    return ( 
        <html lang="en">
        <body className="container">
            <main>
            <div id="wrapper">
                <Header />
                {children}
                {/* <Footer /> */}
                </div>
            </main>
        </body>
      </html>
     );
}
 
export default MainLayout;